//
//  ViewController.swift
//  Demo
//
//  Created by  on 4/5/19.
//  Copyright © 2019 webwerks1. All rights reserved.
//

import UIKit
import RxCocoa
import RxSwift


class ViewController: UIViewController {

    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var tableView: UITableView!
    
    var shownCities = [String]() // Data source for UITableView
    let allCities = ["New York", "London", "Oslo", "Warsaw", "Berlin", "Praga"]
    let disposeBag = DisposeBag()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initialSetUp()
    }
    
    private func initialSetUp(){
        searchBar
            .rx.text
            .orEmpty
            .subscribe(onNext: { [unowned self] query in
                self.shownCities = self.allCities.filter { $0.hasPrefix(query) }
             
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
                
            })
            .disposed(by: disposeBag)
    }
}

extension ViewController : UITableViewDelegate,UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return shownCities.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell : costumCell = tableView.dequeueReusableCell(withIdentifier: "costumCell", for: indexPath) as? costumCell else {
            return UITableViewCell()
        }
        cell.textLabel?.text = self.shownCities[indexPath.row]
        
        return cell
    }
}


class costumCell : UITableViewCell {
    
}
